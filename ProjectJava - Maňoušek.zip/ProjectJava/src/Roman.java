import java.util.ArrayList;

public class Roman extends Kniha 
{
	private String zanr;

	public Roman(String nazev, ArrayList<String> autor,int rokVyd, boolean jeDostupna, String zanr) 
	{
        super(nazev, autor,jeDostupna, rokVyd);
        this.zanr = zanr;
    }
    

    
    public String getZanr() 
    {
        return this.zanr;
    }

}
