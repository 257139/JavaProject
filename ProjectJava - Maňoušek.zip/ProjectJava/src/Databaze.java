import java.sql.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Databaze 
{
	private static final String URL = "url_databaze";
    private static final String UZIVATELSKE_JMENO = "uzivatelske_jmeno";
    private static final String HESLO = "heslo";

    public static void ulozDoDatabaze(List<Kniha> knihy) 
    {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try 
        {
            connection = DriverManager.getConnection(URL, UZIVATELSKE_JMENO, HESLO);
            String sql = "INSERT INTO knihovna (nazev, autor, rok_vydani, dostupnost) VALUES (?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);

            for (Kniha kniha : knihy) 
            {
                preparedStatement.setString(1, kniha.getNazev());
                preparedStatement.setString(2, String.join(",", kniha.getAutor()));
                preparedStatement.setInt(3, kniha.getRokVyd());
                preparedStatement.setBoolean(4, kniha.jeDostupna());
                preparedStatement.executeUpdate();
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        } 
        finally 
        {
            try 
            {
                if (preparedStatement != null) 
                {
                    preparedStatement.close();
                }
                if 
                (connection != null) 
                {
                    connection.close();
                }
            } 
            catch (SQLException e) 
            {
                e.printStackTrace();
            }
        }
    }

    public static void nactiZDatabaze(List<Kniha> knihy) 
    {
        Connection connection = null;
        Statement statement = null;

        try 
        {
            connection = DriverManager.getConnection(URL, UZIVATELSKE_JMENO, HESLO);
            statement = connection.createStatement();
            String sql = "SELECT * FROM knihovna";
            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) 
            {
                String nazev = resultSet.getString("nazev");
                String[] autori = resultSet.getString("autor").split(",");
                ArrayList<String> autorList = new ArrayList<>(Arrays.asList(autori));
                int rokVydani = resultSet.getInt("rok_vydani");
                boolean dostupnost = resultSet.getBoolean("dostupnost");
                Kniha kniha = new Kniha(nazev, autorList, dostupnost, rokVydani);
                knihy.add(kniha);
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        } 
        finally 
        {
            try 
            {
                if (statement != null) 
                {
                    statement.close();
                }
                if (connection != null) 
                {
                    connection.close();
                }
            } 
            catch (SQLException e) 
            {
                e.printStackTrace();
            }
        }
    }
}
