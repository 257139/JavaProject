import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class UlozTXT 
{
    public static void ulozDoSouboru(List<Kniha> knihy) 
    {
        for (Kniha kniha : knihy)
        {
            String souborNazev = kniha.getNazev() + ".txt";
            try (FileWriter writer = new FileWriter(souborNazev)) 
            {
                writer.write("Název: " + kniha.getNazev() + "\n");
                writer.write("Autoři: " + String.join(", ", kniha.getAutor()) + "\n");
                if (kniha instanceof Roman) 
                {
                    writer.write("Žánr: " + ((Roman) kniha).getZanr() + "\n");
                } 
                else if (kniha instanceof Ucebnice) 
                {
                    writer.write("Ročník: " + ((Ucebnice) kniha).getRocnik() + "\n");
                }
                writer.write("Rok vydání: " + kniha.getRokVyd() + "\n");
                writer.write("Stav dostupnosti: " + (kniha.jeDostupna() ? "K dispozici" : "Vypůjčeno") + "\n");
                System.out.println("Informace o knize uloženy do souboru: " + souborNazev);
            } 
            catch (IOException e) 
            {
                System.out.println("Chyba při zápisu do souboru: " + e.getMessage());
            }
        }
    }
}