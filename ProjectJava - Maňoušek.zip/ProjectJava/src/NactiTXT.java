import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class NactiTXT 
{
	public static Kniha nactiKnihuZeSouboru(String fileName) 
	{
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) 
        {
            String nazev = reader.readLine().replace("Název: ", "");
            String autorLine = reader.readLine().replace("Autoři: ", "");
            String[] autorArray = autorLine.split(", ");
            ArrayList<String> autor = new ArrayList<>();
            for (String author : autorArray) 
            {
                autor.add(author.trim());
            }
            String zanrNeboRocnik = reader.readLine();
            int rokVyd = Integer.parseInt(reader.readLine().replace("Rok vydání: ", ""));
            boolean jeDostupna = reader.readLine().replace("Stav dostupnosti: ", "").equals("K dispozici");

            Kniha kniha;
            if (zanrNeboRocnik.startsWith("Žánr:")) 
            {
                String zanr = zanrNeboRocnik.replace("Žánr: ", "");
                kniha = new Roman(nazev, autor, rokVyd, jeDostupna, zanr);
            } 
            else 
            {
                int rocnik = Integer.parseInt(zanrNeboRocnik.replace("Ročník: ", ""));
                kniha = new Ucebnice(nazev, autor, rokVyd, jeDostupna, rocnik);
            }
            return kniha;
        } 
        catch (IOException e) 
        {
            System.out.println("Chyba při čtení ze souboru: " + e.getMessage());
            return null;
        }
    }
}
