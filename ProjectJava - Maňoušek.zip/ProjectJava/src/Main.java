import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main 
{
    private static Knihovna knihovna = new Knihovna();
    private static Scanner scanner = new Scanner(System.in);
    
    
   
    

    public static void main(String[] args) 
    {
    	Databaze.nactiZDatabaze(Knihovna.getKnihy());
    Runtime.getRuntime().addShutdownHook(new Thread(() -> {
        Databaze.ulozDoDatabaze(Knihovna.getKnihy());
    }));
        boolean main = true;

        while (main) 
        {
        	System.out.println("\nMenu:");
            System.out.println("1. Přidat knihu");
            System.out.println("2. Upravit knihu");
            System.out.println("3. Odstranit knihu");
            System.out.println("4. Označit knihu jako vypůjčenou/vrácenou");
            System.out.println("5. Zobrazit seznam knih");
            System.out.println("6. Vyhledat knihu");
            System.out.println("7. Výpis všech knih daného autora v chronologickém pořadí");
            System.out.println("8. Výpis všech knih daného žánru");
            System.out.println("9. Výpis všech vypůjčených knih");
            System.out.println("10. Uložit informace o knihách do souboru");
            System.out.println("11. Načíst informace o knize ze souboru");
            System.out.println("12. Ukončit program");
            System.out.print("Vyberte akci: ");

            int volba = scanner.nextInt();
            scanner.nextLine(); 

            switch (volba) 
            {
            case 1:
                pridejKnihu(scanner);
                break;
            case 2:
                upravKnihu(scanner);
                break;
            case 3:
                odstranKnihu();
                break;
            case 4:
                zmenaStatusKniha(scanner);
                break;
            case 5:
                zobrazKnihy();
                break;
            case 6:
            	vyhledatKnihu(scanner);
                break;
            case 7:
            	knihyPodleAutora(scanner);
                break;
            case 8:
            	knihyPodleZanru(scanner);
                break;
            case 9:
            	zobrazVypujcKnihy();
                break;
            case 10:
                UlozTXT.ulozDoSouboru(Knihovna.getKnihy());
                break;
            case 11:
            	nactiKnihuZeSouboru(scanner);
                break;
            case 12:
                main = false;
                break;
            default:
                System.out.println("Neplatná volba. Zvolte prosím znovu.");
            }
        }

        scanner.close();
    }

    public static void pridejKnihu(Scanner scanner) 
    {
    	 
    	 
    	String type;
        do {
            System.out.println("Vyberte typ knihy (Román/Učebnice):");
            type = scanner.next();
            if (!type.equalsIgnoreCase("Román") && !type.equalsIgnoreCase("Učebnice")) 
            {
                System.out.println("Neplatný typ knihy. Zadejte prosím 'Román' nebo 'Učebnice'.");
            }
        } while (!type.equalsIgnoreCase("Román") && !type.equalsIgnoreCase("Učebnice"));
        
        
        System.out.println("Zadejte název knihy:");
        String nazev = scanner.next();

        System.out.println("Zadejte autora/autory (oddělte čárkou):");
        String[] autorArray = scanner.next().split(",");
        ArrayList<String> autor = new ArrayList<>();
        for (String author : autorArray) 
        {
            autor.add(author.trim());
        }

        boolean rokKontrola = false;
        int rokVyd = 0;
        while (!rokKontrola) 
        {
            System.out.println("Zadejte rok vydání:");
            if (scanner.hasNextInt()) 
            {
                rokVyd = scanner.nextInt();
                rokKontrola = true;
            } 
            else 
            {
                System.out.println("Neplatná hodnota. Zadejte prosím číslo.");
                scanner.next(); 
            }
        }
        scanner.nextLine(); 
        
        
        boolean jeDostupna =false; 
        boolean vstupKontrola = false; 
        do {
            System.out.println("Je kniha k dispozici? (true/false):");
            String availableInput = scanner.nextLine();
            
            if (availableInput.equalsIgnoreCase("true")) 
            {
                jeDostupna = true;
                vstupKontrola = true; 
            } 
            else if (availableInput.equalsIgnoreCase("false")) 
            {
                jeDostupna = false;
                vstupKontrola = true; 
            } 
            else 
            {
                System.out.println("Neplatná hodnota. Zadejte prosím true nebo false.");
            }
        } while (!vstupKontrola);
        
        

        if (type.equalsIgnoreCase("Román")) 
        {
            System.out.println("Zadejte žánr:");
            String zanr = scanner.next();
            Kniha kniha = new Roman(nazev, autor, rokVyd, jeDostupna, zanr);
            knihovna.pridejKnihu(kniha); 
            
        } 
        else if (type.equalsIgnoreCase("Učebnice")) 
        {
            System.out.println("Zadejte ročník:");
            int rocnik = scanner.nextInt();
            Kniha kniha = new Ucebnice(nazev, autor, rokVyd, jeDostupna, rocnik);
            knihovna.pridejKnihu(kniha);
            
        } 
        else 
        {
            System.out.println("Neplatný typ knihy.");
        }
    }
    
    private static void upravKnihu(Scanner scanner) 
    {
        System.out.print("Zadejte název knihy, kterou chcete upravit: ");
        String nazev = scanner.nextLine();

        Kniha kniha = knihovna.najdiKnihu(nazev);
        if (kniha == null) 
        {
            System.out.println("Kniha s názvem " + nazev + " nebyla nalezena.");
            return;
        }

        System.out.println("Vyberte, který parametr knihy chcete upravit:");
        System.out.println("1. Autor/autory");
        System.out.println("2. Rok vydání");
        System.out.println("3. Stav dostupnosti");
        int volbaZmena = scanner.nextInt();
        scanner.nextLine(); 

        switch (volbaZmena) 
        {
            case 1:
                System.out.print("Zadejte nového autora/autory (oddělte čárkou): ");
                String[] autorArray = scanner.nextLine().split(",");
                ArrayList<String> autor = new ArrayList<>();
                for (String author : autorArray) 
                {
                    autor.add(author.trim());
                }
                kniha.setAutor(autor);
                break;
            case 2:
                boolean kontrolaRokVyd = false; 
                do {
                    System.out.print("Zadejte nový rok vydání: ");
                    if (scanner.hasNextInt()) 
                    {
                        int rokVyd = scanner.nextInt();
                        kniha.setRokVyd(rokVyd);
                        kontrolaRokVyd = true; 
                    } 
                    else 
                    {
                        System.out.println("Neplatná hodnota. Zadejte prosím celé číslo.");
                        scanner.nextLine(); 
                    }
                } while (!kontrolaRokVyd);
                break;
            case 3:
                boolean jeDostupna = false; 
                boolean kontrolaStav = false; 
                do {
                    System.out.print("Zadejte nový stav dostupnosti (true/false): ");
                    String dostupnostInput = scanner.nextLine();
                    if (dostupnostInput.equalsIgnoreCase("true")) 
                    {
                        jeDostupna = true;
                        kontrolaStav = true; 
                    }
                    else if (dostupnostInput.equalsIgnoreCase("false")) 
                    {
                        jeDostupna = false;
                        kontrolaStav = true; 
                    } 
                    else 
                    {
                        System.out.println("Neplatná hodnota. Zadejte prosím true nebo false.");
                    }
                } while (!kontrolaStav);
                
                kniha.setDostunost(jeDostupna);
                break;
            default:
                System.out.println("Neplatná volba.");
                return;
        }

        System.out.println("Kniha byla úspěšně upravena.");
    }
    
    private static void zmenaStatusKniha(Scanner scanner) 
    {
        System.out.print("Zadejte název knihy, kterou chcete označit jako vypůjčenou/vrácenou: ");
        String nazev = scanner.nextLine();

        Kniha kniha = knihovna.najdiKnihu(nazev);
        if (kniha == null) 
        {
            System.out.println("Kniha s názvem " + nazev + " nebyla nalezena.");
            return;
        }

        System.out.println("Je kniha vypůjčená nebo vrácená? (vypůjčená/vrácená)");
        String status = scanner.nextLine();
        boolean jeDostupna = status.equalsIgnoreCase("vrácená");

        kniha.setDostunost(jeDostupna);
        System.out.println("Stav knihy byl úspěšně aktualizován.");
    }
    
    private static void vyhledatKnihu(Scanner scanner) 
    {
        System.out.print("Zadejte název knihy: ");
        String nazev = scanner.nextLine();

        Kniha kniha = knihovna.najdiKnihu(nazev);
        if (kniha == null) 
        {
            System.out.println("Kniha s názvem " + nazev + " nebyla nalezena.");
        } 
        else 
        {
        	
            System.out.println("Informace o knize:");
            if (kniha instanceof Roman) 
        	{
                System.out.println("Román");
            } 
        	else if (kniha instanceof Ucebnice) 
        	{
                System.out.println("Učebnice");
            }
            System.out.println("Název: " + kniha.getNazev());
            System.out.println("Autor/Autoři: " + String.join(", ", kniha.getAutor())); 
            System.out.println("Rok vydání: " + kniha.getRokVyd());
            System.out.println("Stav dostupnosti: " + (kniha.jeDostupna() ? "Dostupná" : "Vypůjčená"));
        }
    }
    
    private static void knihyPodleAutora(Scanner scanner) 
    {
        System.out.print("Zadejte jméno autora: ");
        String autor = scanner.nextLine();

        List<Kniha> knihyPodleAutora = knihovna.najdiKnihuPodleAutora(autor);
        if (knihyPodleAutora.isEmpty()) 
        {
            System.out.println("Kniha od autora " + autor + " nebyla nalezena.");
        } 
        else 
        {
            System.out.println("Knihy od autora " + autor + ":");
            for (Kniha kniha : knihyPodleAutora) {
                System.out.println("Název: " + kniha.getNazev());
                System.out.println("Autoři: " + String.join(", ", kniha.getAutor()));
                if (kniha instanceof Roman) 
                {
                    System.out.println("Typ: Román");
                } 
                else if (kniha instanceof Ucebnice) 
                {
                    System.out.println("Typ: Učebnice");
                }
                System.out.println("Rok vydání: " + kniha.getRokVyd());
                System.out.println("Stav dostupnosti: " + (kniha.jeDostupna() ? "Dostupná" : "Vypůjčená"));
                System.out.println();
            }
        }
    }
    
    private static void knihyPodleZanru(Scanner scanner) 
    {
        System.out.print("Zadejte žánr knih, které chcete vypsat: ");
        String zanr = scanner.nextLine();

        ArrayList<Kniha> knihyPodleZanru = knihovna.najdiKnihuPodleZanru(zanr);
        if (knihyPodleZanru.isEmpty())
        {
            System.out.println("Žádné knihy nalezeny pro žánr " + zanr + ".");
            return;
        }

        System.out.println("Knihy žánru " + zanr + ":");
        for (Kniha kniha : knihyPodleZanru) 
        {
            System.out.println("Název: " + kniha.getNazev());
        }
    }
    
    private static void zobrazVypujcKnihy() 
    {
        List<Kniha> vypujceneKnihy = knihovna.vypujceneKnihy();
        if (vypujceneKnihy.isEmpty()) 
        {
            System.out.println("Žádné vypůjčené knihy nejsou k dispozici.");
            return;
        }
        else
        {
         System.out.println("Vypůjčené knihy:");
         for (Kniha kniha : vypujceneKnihy) 
         {
            if (kniha instanceof Roman) 
            {
                System.out.println("Román: " + kniha.getNazev());
            } 
            else if (kniha instanceof Ucebnice) 
            {
                System.out.println("Učebnice: " + kniha.getNazev());
            }
         }
        }
    }


    private static void odstranKnihu() 
    {
        System.out.print("Název knihy k odstranění: ");
        String nazev = scanner.nextLine();
        knihovna.odstranKnihu(nazev);
    }

    private static void zobrazKnihy() 
    {
        knihovna.zobrazKnihy();
    }
    
    private static void nactiKnihuZeSouboru(Scanner scanner) 
    {
        System.out.print("Zadejte název souboru s informacemi o knize: ");
        String fileName = scanner.nextLine();
        Kniha kniha = NactiTXT.nactiKnihuZeSouboru(fileName);
        if (kniha != null) 
        {
            knihovna.pridejKnihu(kniha);
        } 
        else 
        {
            System.out.println("Nepodařilo se načíst informace o knize ze souboru.");
        }
    }
}
