import java.util.ArrayList;

public class Ucebnice extends Kniha
{
	 private int rocnik;
	 

	 public Ucebnice(String nazev, ArrayList<String> autor,int rokVyd, boolean jeDostupna, int rocnik) 
	 {
	        super(nazev, autor, jeDostupna, rokVyd);
	        this.rocnik = rocnik;
	    }

	   
	    public int getRocnik() 
	    {
	        return this.rocnik;
	    }
	}

