import java.util.ArrayList;

public class Kniha 
{
	private String nazev;
	    private ArrayList<String> autor;
	    private boolean jeDostupna;
		private int rokVyd;
	

		public Kniha(String nazev, ArrayList<String> autor, boolean jeDostupna, int rokVyd) 
		{
		    this.nazev = nazev;
		    this.autor = autor;
		    this.rokVyd = rokVyd;
		    this.jeDostupna = jeDostupna;
		}


	    public String getNazev() 
	    {
	        return nazev;
	    }
	    
	    public void setAutor(ArrayList<String> autor) 
	    {
	        this.autor = autor;
	    }

	    public void setDostunost(boolean jeDostupna) 
	    {
	        this.jeDostupna = jeDostupna;
	    }

	    public void setRokVyd(int rokVyd) 
	    {
	        this.rokVyd = rokVyd;
	    }
	    
	    public ArrayList<String> getAutor() 
	    {
	        return this.autor;
	    }

	    public int getRokVyd() 
	    {
	        return this.rokVyd;
	    }

	    public boolean jeDostupna() 
	    {
	        return this.jeDostupna;
	    }

		
	}

