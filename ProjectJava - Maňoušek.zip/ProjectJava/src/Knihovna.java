import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class Knihovna 
{
	 private static List<Kniha> knihy;
	 private List<Kniha> vypujceneKnihy;
	 
	    public Knihovna() 
	    {
	        knihy = new ArrayList<>();
	        vypujceneKnihy = new ArrayList<>();
	    }

	   
	    public void pridejKnihu(Kniha kniha) 
	    {
	        knihy.add(kniha);
	    }

	   
	    public void odstranKnihu(String nazev) 
	    {
	        knihy.removeIf(kniha -> kniha.getNazev().equals(nazev));
	    }

	   
	    public void zobrazKnihy() 
	    {
	    	
	        Collections.sort(knihy, (kniha1, kniha2) -> kniha1.getNazev().compareToIgnoreCase(kniha2.getNazev()));

	        
	        for (Kniha kniha : knihy) 
	        {
	        	if (kniha instanceof Roman) 
	        	{
	                System.out.println("Román");
	            } 
	        	else if (kniha instanceof Ucebnice) 
	            {
	                System.out.println("Učebnice");
	            }
	        	
	            System.out.println("Název: " + kniha.getNazev());
	            System.out.print("Autor/Autoři: ");
	            for (String author : kniha.getAutor()) 
	            {
	                System.out.print(author);
	            }
	            System.out.println();
	            if (kniha instanceof Roman) 
	            {
	                System.out.println("Žánr: " + ((Roman) kniha).getZanr());
	            } 
	            else if (kniha instanceof Ucebnice) 
	            {
	                System.out.println("Ročník: " + ((Ucebnice) kniha).getRocnik());
	            }
	            System.out.println("Rok vydání: " + kniha.getRokVyd());
	            System.out.println("Stav dostupnosti: " + (kniha.jeDostupna() ? "Dostupná" : "Vypůjčená"));
	            System.out.println();
	        }
	       
	    }

		public static List<Kniha> getKnihy() 
		{
		
			return knihy;
		}
		
		public Kniha najdiKnihu(String nazev) 
		{
	        for (Kniha kniha : knihy) 
	        {
	            if (kniha.getNazev().equals(nazev)) 
	            {
	                return kniha;
	            }
	        }
	        return null;
	    }
		
		
		public ArrayList<Kniha> najdiKnihuPodleAutora(String authorName) 
		{
	        ArrayList<Kniha> knihyPodleAutora = new ArrayList<>();
	        for (Kniha kniha : knihy) {
	            if (kniha.getAutor().contains(authorName)) 
	            {
	                knihyPodleAutora.add(kniha);
	            }
	        }
	        return knihyPodleAutora;
	    }
		
		public ArrayList<Kniha> najdiKnihuPodleZanru(String zanr) 
		{
	        ArrayList<Kniha> knihyPodleZanru = new ArrayList<>();
	        for (Kniha kniha : knihy) 
	        {
	            if (kniha instanceof Roman && ((Roman) kniha).getZanr().equalsIgnoreCase(zanr)) 
	            {
	                knihyPodleZanru.add(kniha);
	            }
	        }
	        return knihyPodleZanru;
	    }
		
		public List<Kniha> vypujceneKnihy() 
		{
		    return new ArrayList<>(vypujceneKnihy);
		}
		
	
		
		
}
